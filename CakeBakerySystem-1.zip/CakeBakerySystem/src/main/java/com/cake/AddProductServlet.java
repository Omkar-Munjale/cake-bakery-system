package com.cake;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.InputStream;
import javax.servlet.annotation.MultipartConfig;

@WebServlet("/AddProductServlet")
@MultipartConfig(maxFileSize = 16177215) // 16 MB max file size
public class AddProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private String dbURL = "jdbc:mysql://localhost:3306/cakebakery";
    private String dbUser = "root";
    private String dbPassword = "Pass@0987";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        double discount = Double.parseDouble(request.getParameter("discount"));
        
        InputStream inputStream = null; // इमेजसाठी इनपुट स्ट्रीम
        
        try {
            Part filePart = request.getPart("image");
            if (filePart != null) {
                inputStream = filePart.getInputStream();
            }
        } catch (Exception ex) {
            response.getWriter().println("File upload error: " + ex.getMessage());
            return;
        }
        
        Connection conn = null;
        String message = null;
        
        try {
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            
            String sql = "INSERT INTO products (product_name, description, price, discount, image) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            
            statement.setString(1, productName);
            statement.setString(2, description);
            statement.setDouble(3, price);
            statement.setDouble(4, discount);
            
            if (inputStream != null) {
                statement.setBlob(5, inputStream);
            }
            
            statement.executeUpdate();
        } catch (Exception ex) {
            message = "Error: " + ex.getMessage();
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            request.setAttribute("Message", message);
            getServletContext().getRequestDispatcher("/ProductAddSuccessfully.jsp").forward(request, response);
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}