package com.cake;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/CheckSessionServlet")
public class CheckSessionServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        Object userId = (session != null) ? session.getAttribute("userid") : null;

        String productId = request.getParameter("id");

        if (userId == null) {
        	PrintWriter out=response.getWriter();
            response.setContentType("text/html");
        	out.println("<script type='text/javascript'>");
        	out.println("alert('Please login to continue...!');");
        	out.println("window.location='login.jsp';");
        	out.println("</script>");
            return;
        } else {
            response.sendRedirect("ViewProduct.jsp?id=" + productId);
        }
    }
}
