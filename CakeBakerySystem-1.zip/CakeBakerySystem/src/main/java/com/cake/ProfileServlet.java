package com.cake;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
@WebServlet("/Profile")
public class ProfileServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userid") == null) {
            response.sendRedirect("login.html");
            return;
        }
        int userid = (int) session.getAttribute("userid");
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cakebakery","root","Pass@0987");
            PreparedStatement ps = con.prepareStatement("SELECT username, email, phone, address FROM register_tb WHERE id=?");
            ps.setInt(1, userid);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                request.setAttribute("username", rs.getString("username"));
                request.setAttribute("email", rs.getString("email"));
                request.setAttribute("phone", rs.getLong("phone"));
                request.setAttribute("address", rs.getString("address"));
            }
            
            rs.close();
            ps.close();
            con.close();

            RequestDispatcher rd = request.getRequestDispatcher("Profile.jsp");
            rd.forward(request, response);
        
        }
        
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}