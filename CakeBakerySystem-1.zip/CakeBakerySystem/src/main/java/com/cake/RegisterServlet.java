package com.cake;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fullname = request.getParameter("fullname");
		String address = request.getParameter("address");
		String email = request.getParameter("email");
		Long phone = Long.parseLong(request.getParameter("phone"));
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/cakebakery", "root", "Pass@0987");
            
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO register_tb (fullname,address,email,phone,username, password) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setString(1, fullname);
            ps.setString(2, address);
            ps.setString(3, email);
            ps.setLong(4, phone);
            ps.setString(5, username);
            ps.setString(6, password);

            int count = ps.executeUpdate();
            
            if(count == 1) {
            	PrintWriter out=response.getWriter();
                response.setContentType("text/html");
            	out.println("<script type='text/javascript'>");
            	out.println("alert('Registered Successfully. Login to Continue...!');");
            	out.println("window.location='login.jsp';");
            	out.println("</script>");
                return;
            }
            else {
            	response.sendRedirect("Register.html");
            }
            ps.close();
            con.close();            
            response.sendRedirect("login.jsp");
		
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }

	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
